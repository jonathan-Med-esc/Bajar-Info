/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EJ1;

/**
 *
 * @author jonathan.medesc
 */
public class Vago extends Pokemon {

    public Vago() {
        super();
    }

  

    @Override
    public String hablar() {
        return "Duerme zzz";
    }

}
